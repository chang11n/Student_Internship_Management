﻿Partial Class DataSet2
    Partial Class DataTable2DataTable

        
    End Class

End Class
